// Importing necessary React components and the Google Maps API wrapper
import React,{Component} from 'react';
import {Map, InfoWindow, Marker, GoogleApiWrapper} from 'google-maps-react';

// Class-based component for displaying a Google Map
export class MapContainer extends Component {
    
    render() {
      // Setting the style for the map container
        const style = {
            width: '100%',
            height: '100%' 
        }

      return (
        // Google Map component with specified properties
        <Map google={this.props.google} zoom={15}
            style={style}
            initialCenter={{
            lat: this.props.latitude,
            lng: this.props.longitude
            }}
        >
   
          <Marker onClick={this.onMarkerClick}
                  name={'Current location'} />
   
          <InfoWindow onClose={this.onInfoWindowClose}>
              {/* <div>
                <h1>University Location</h1>
              </div> */}
          </InfoWindow>
        </Map>
      );
    }
}
   

// Exporting the MapContainer component with the Google API wrapper
export default GoogleApiWrapper({
    apiKey: 'AIzaSyBha2m_o8kKChjguj0zmwp0xK3H0Mq03hg'// API key
  })(MapContainer);
