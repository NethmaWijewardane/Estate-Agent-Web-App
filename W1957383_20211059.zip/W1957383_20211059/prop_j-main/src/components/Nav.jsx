// Importing necessary React modules, CSS styles, and components
import * as React from 'react';
import './css/Nav.css'
import Button from './Button';
import { Link, useNavigate } from 'react-router-dom';

// Functional component for the navigation bar
export function Nav (props) {
// Creating a navigation function using the useNavigate hook from React Router
    let navigate = useNavigate();
    
  return (
    <div className='nav-container'>
      {/* <Button label='Favourits' onClick={() => navigate(`/favourit`)}/> */}
      {/* <Link to={'/favourit'} style={{
        // color: 'white'
      }}>Favourit</Link> */}
        <div className='nav-head' onClick={() => navigate(`/`)}>
        Home
        </div>
      <div className='nav-head' onClick={() => navigate(`/favourit`)}>
        Favourits
      </div>
    </div>
  );
}
