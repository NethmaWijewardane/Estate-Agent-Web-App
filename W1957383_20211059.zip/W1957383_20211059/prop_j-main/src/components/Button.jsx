// Importing necessary React modules and CSS styles
import * as React from 'react';
import './css/Button.css'

// Functional component for a custom button
export default function Button (props) {
  return (
    <div className='button-cont'>
        <button 
            onClick={props.onClick}
            className='custom-button'
        >
            {props.label}
        </button>
    </div>
  );
}
