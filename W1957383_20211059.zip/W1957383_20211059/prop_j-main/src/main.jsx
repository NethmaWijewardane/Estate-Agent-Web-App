// Importing necessary modules and components
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import DOMPurify from 'dompurify';

// Rendering the main App component within a React Strict Mode for additional checks
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>, 
)
// Defining a reusable component 'MyComponent' that sanitizes and renders user-provided HTML content
function MyComponent({ userContent }) {
  // Sanitize the user-provided content using DOMPurify
  const sanitizedContent = DOMPurify.sanitize(userContent);
  // Render a div with dangerouslySetInnerHTML to insert sanitized HTML content
  return <div dangerouslySetInnerHTML={{ __html: sanitizedContent }} />;
}
